package com.example.Lab1_GS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab1GsApplicationTests {

	@Test
	void contextLoads() {
	}

}
