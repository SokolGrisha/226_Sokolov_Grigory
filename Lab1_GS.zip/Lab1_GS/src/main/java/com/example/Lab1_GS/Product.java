package com.example.Lab1_GS;

public interface Product {

}
