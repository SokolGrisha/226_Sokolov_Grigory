package com.example.Lab1_GS;

public class RandomBox extends BP implements Product{
    private int hwinbixbox;
    public RandomBox(){
        hwinbixbox=0;
    }
}
