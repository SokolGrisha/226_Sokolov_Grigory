package com.example.Lab1_GS;

public class KeyFigure extends BP implements Product{
    public KeyFigure(){
        this.key=true;
    }
}
