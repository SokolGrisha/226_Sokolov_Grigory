package com.example.Lab1_GS;

public class Figure extends BP implements Product{

}
